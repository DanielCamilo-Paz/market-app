/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package logic;

import data.Node;

/**
 *
 * @author Estudiantes
 */
public class Queue {

    Node h;

    //write
    public void push(Node n) {
        if (n != null) {
            if (h == null) {
                h = n;
            } else {
                Node aux = h;
                while (aux.next != null) {
                    aux = aux.next;
                }
                aux.next = n;
            }
        }
    }

    //read
    public Node pop() {

        Node r = h;
        if (h != null) {
            h = h.next;
        } else {
            System.out.println("Queue is Empty");
        }

        return r;
    }

    public void show() {
        System.out.println("Showing Queue...\n");
        if (h != null) {
            Node aux = h;
            while (aux.next != null) {
                System.out.print(aux.toString());
                aux = aux.next;
            }
            System.out.print(aux.toString());

        } else {
            System.out.println("Queue is empty...");
        }

    }
}
