/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package logic;

import data.Node;

/**
 *
 * @author Estudiantes
 */
public class SimpleList {

    Node h;
    int size;

    public SimpleList() {
        h = null;
        size = 0;
    }

    public void addStart(Node n) {
        if (n != null) {
            n.next = h;
            h = n;
            size++;
        }
    }

    public void addEnd(Node n) {
        if (n != null) {
            if (h == null) {
                h = n;
                size++;
            } else {
                Node aux = h;
                while (aux.next != null) {
                    aux = aux.next;
                }
                aux.next = n;
                size++;
            }
        }
    }

    public void addBetweenSortAsc(Node n) {
        if (n != null) {
            Node aux = h;
            if (n.value > aux.value) {
                n.next = aux;
                h = n;
            } else {
                while (aux.next != null) {
                    if (n.value < aux.value && n.value > aux.next.value) {
                        n.next = aux.next;
                        aux.next = n;
                        break;
                    } else {
                        aux = aux.next;
                    }
                }
                aux.next = n;
            }
        }
    }

    public void addBetween(Node n, int ii) {
        if (ii <= 0) {
            addStart(n);
        } else if (ii >= size) {
            addEnd(n);
        } else {
            int c = 0;
            Node aux = h;
            while (aux.next != null) {
                if (c < ii) {
                    aux = aux.next;
                    c++;
                } else {
                    break;
                }
            }
            n.next = aux.next;
            aux.next = n;
            size++;

        }
    }

    public Node removeStart() {
        Node r = h;
        if (h != null) {
            h = h.next;
            size--;
        } else {
            size = 0;
            System.out.println("List is Empty");
        }

        return r;
    }

    public Node removeEnd() {
        return null;
    }

    public Node removeBetween() {
        return null;
    }

    public void show() {
        System.out.println("Showing List (" + size + ")...\n");
        if (h != null) {
            Node aux = h;
            while (aux.next != null) {
                System.out.print(aux.toString());
                aux = aux.next;
            }
            System.out.print(aux.toString());

        } else {
            System.out.println("List is empty...");
        }

    }
}
