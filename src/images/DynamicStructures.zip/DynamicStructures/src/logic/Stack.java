/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package logic;

import data.Node;

/**
 *
 * @author Estudiantes
 */
public class Stack {

    Node h = null;

    //write
    public void push(Node n) {
        if (n != null) {
            n.next = h;
            h = n;
        }
    }

    //read
    public Node pop() {
        Node r = h;
        if (h != null) {
            h = h.next;
        } else {
            System.out.println("Stack is Empty");
        }

        return r;
    }

    public void show() {
        System.out.println("Showing Stack...\n");
        if (h != null) {
            Node aux = h;
            while (aux.next != null) {
                System.out.print(aux.toString());
                aux = aux.next;
            }
            System.out.print(aux.toString());
        } else {
            System.out.println("Stack is empty...");
        }
    }

}
