/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package logic;

import data.CircularNode;
public class CircularList {
    CircularNode h;
    int size;
    public CircularList() {
        h = null;
        size = 0;
    }
}
