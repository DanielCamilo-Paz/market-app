/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package dynamicstructures;

import data.Node;
import data.Pet;
import logic.Queue;
import logic.SimpleList;
import logic.Stack;

/**
 *
 * @author Estudiantes
 */
public class DynamicStructures {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        SimpleList sl = new SimpleList();
        sl.addBetween(new Node(5), 100);
        sl.addBetween(new Node(50), -10);
        sl.addBetween(new Node(3), 1);
        sl.addBetween(new Node(8), 1);
        sl.addBetween(new Node(14), 2);
               
        sl.show();
        
        sl.removeStart();
        sl.show();
        
        
        sl.removeStart();
        sl.show();
        
        
        sl.removeStart();
        sl.show();
        
        
        sl.removeStart();
        sl.show();
        
        
        sl.removeStart();
        sl.show();
        
        
        sl.removeStart();
        sl.show();
        
        
        sl.removeStart();
        sl.show();
        
        
        sl.removeStart();
        sl.show();
        
        
        sl.removeStart();
        sl.show();
        
        /*
        sl.addStart(new Node(-5));
        sl.addStart(new Node(-10));
        sl.addStart(new Node(-15));
        sl.show();
        sl.addEnd(new Node(5));
        sl.addEnd(new Node(10));
        sl.addEnd(new Node(15));
        sl.show();
        sl.addBetweenSortAsc(new Node(50));
        sl.show();
        sl.addBetweenSortAsc(new Node(40));
        sl.show();
        sl.addBetweenSortAsc(new Node(30));
        sl.show();
        sl.addBetweenSortAsc(new Node(90));
        sl.show();
        sl.addBetweenSortAsc(new Node(1));
        sl.show();
        sl.addBetweenSortAsc(new Node(30));
        sl.show();
         */

    }

}
