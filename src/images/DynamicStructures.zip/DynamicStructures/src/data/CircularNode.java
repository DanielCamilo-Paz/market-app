/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package data;

/**
 *
 * @author Docentes
 */
public class CircularNode {
    int value;
    CircularNode next;
    public CircularNode(int v) {
        value = v;
        next = this;
    }    
    @Override
    public String toString() {
        String st
                = "Value: " + value + "\n";
        return st;
    }
}
