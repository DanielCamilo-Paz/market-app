/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package data;

/**
 *
 * @author Estudiantes
 */
public class Pet {

    String name;
    int age;
    char gender;
    boolean vaccine;
    boolean isAlive;

    public Pet(String name, int age, char gender, boolean vaccine, boolean isAlive) {
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.vaccine = vaccine;
        this.isAlive = isAlive;
    }

    @Override
    public String toString() {

        String st
                = "Name: " + name + "\n"
                + "Age: " + age + "\n"
                + "Gender: " + gender + "\n"
                + "Vaccine: " + (vaccine ? "Yes" : "No") + "\n"
                + (isAlive ? "Alive" : "Dead") + "\n";

        return st; // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

}
