/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package data;

/**
 *
 * @author Estudiantes
 */
public class NodeB {

    //data saving area
    Pet value;
    //address saving area
    Node next;

    public NodeB(Pet v) {
        value = v;
        next = null;
    }

}
