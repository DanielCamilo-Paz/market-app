/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package data;

/**
 *
 * @author Estudiantes
 */
public class Node {

    //data saving area
    public int value;
    //address saving area
    public Node next;

    public Node(int v) {
        value = v;
        next = null;
    }

    @Override
    public String toString() {
        String st
                = "Value: " + value + "\n";
        return st;
    }
}
